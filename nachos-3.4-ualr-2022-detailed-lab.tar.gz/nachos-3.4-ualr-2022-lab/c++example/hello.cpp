#include <iostream>



int main()
{
  std::cout << "Hello~\n";
  return 0;
}
