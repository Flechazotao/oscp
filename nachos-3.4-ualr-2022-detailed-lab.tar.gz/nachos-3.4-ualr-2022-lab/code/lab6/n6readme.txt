Lab6 系统调用与多道用户程序
2022.5.5

本目录下的可执行程序n6为Lab6的一个参考实现。

输入下面的指令，进行测试(需要先完成../test/exec.c及../test/halt2.c的编写及编译)：
./n6 -x ../test/exec.noff

对自己编写生成的程序，命令行为：
./nachos -x ../test/exec.noff
